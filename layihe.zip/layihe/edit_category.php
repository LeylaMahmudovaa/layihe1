<?php
require 'connection.php';

session_start();


if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin' || !isset($_SESSION['verified'])) {
    header('Location: login.php');
    exit;
}


if (isset($_GET['id'])) {
    $category_id = $_GET['id'];

    
    if (!filter_var($category_id, FILTER_VALIDATE_INT)) {
        echo "Yanlış kateqoriya ID.";
        exit;
    }

   
    $stmt = $conn->prepare("SELECT * FROM categories WHERE id = :id");
    $stmt->bindParam(':id', $category_id, PDO::PARAM_INT);
    $stmt->execute();
    $category = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$category) {
        echo "Kateqoriya tapılmadı.";
        exit;
    }
} else {
    echo "Yanlış kateqoriya ID.";
    exit;
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $description = $_POST['description'];

    
    $stmt = $conn->prepare("UPDATE categories SET name = :name, description = :description WHERE id = :id");
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':description', $description);
    $stmt->bindParam(':id', $category_id, PDO::PARAM_INT);

    if ($stmt->execute()) {
        header('Location: categories.php');
        exit;
    } else {
        echo "Kateqoriyanı yeniləmək mümkün olmadı.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kateqoriyanı Redaktə Et</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            padding: 20px;
        }

        .edit-form {
            width: 100%;
            max-width: 400px;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }

        .edit-form h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-group input[type="text"],
        .form-group textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .form-group button {
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            border: none;
            border-radius: 4px;
            color: white;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .form-group button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="edit-form">
        <h2>Kateqoriyanı Redaktə Et</h2>
        <form method="POST">
            <div class="form-group">
                <label for="name">Ad</label>
                <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($category['name']); ?>" required>
            </div>
            <div class="form-group">
                <label for="description">Təsvir</label>
                <textarea id="description" name="description" required><?php echo htmlspecialchars($category['description']); ?></textarea>
            </div>
            <div class="form-group">
                <button type="submit">Kateqoriyanı Yenilə</button>
            </div>
        </form>
    </div>
</body>
</html>




