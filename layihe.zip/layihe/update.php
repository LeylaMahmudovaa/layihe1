<?php

ini_set('session.gc_maxlifetime', 3600); 
session_set_cookie_params(3600);


session_start();


if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}


require 'connection.php';


$user_id = $_SESSION['user_id'];


$stmt = $conn->prepare("SELECT * FROM users WHERE id = :id");
$stmt->bindParam(':id', $user_id, PDO::PARAM_INT);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    echo "İstifadəçi tapılmadı.";
    exit;
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $middle_name = $_POST['middle_name'];
    $birth_date = $_POST['birth_date'];
    $gender = $_POST['gender'];

    
    if (!empty($_FILES['profile_image']['name'])) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        $file_type = mime_content_type($_FILES['profile_image']['tmp_name']);

        if (in_array($file_type, $allowed_types)) {
            $profile_image = uniqid() . '_' . basename($_FILES['profile_image']['name']);
            $target_dir = "uploads/";
            $target_file = $target_dir . $profile_image;

            if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $target_file)) {
                
                if (!empty($user['profile_image']) && file_exists("uploads/" . $user['profile_image'])) {
                    unlink("uploads/" . $user['profile_image']);
                }
            } else {
                echo "Şəkil yüklənmədi.";
                exit;
            }
        } else {
            echo "Yalnız JPEG, PNG və GIF formatında şəkillər yükləyə bilərsiniz.";
            exit;
        }
    } else {
        $profile_image = $user['profile_image'];
    }

    
    $stmt = $conn->prepare("UPDATE users SET first_name = :first_name, last_name = :last_name, middle_name = :middle_name, birth_date = :birth_date, gender = :gender, profile_image = :profile_image WHERE id = :id");
    $stmt->bindParam(':first_name', $first_name);
    $stmt->bindParam(':last_name', $last_name);
    $stmt->bindParam(':middle_name', $middle_name);
    $stmt->bindParam(':birth_date', $birth_date);
    $stmt->bindParam(':gender', $gender);
    $stmt->bindParam(':profile_image', $profile_image);
    $stmt->bindParam(':id', $user_id, PDO::PARAM_INT);

    if ($stmt->execute()) {
       
        header('Location: user_dashboard.php');
        exit;
    } else {
        echo "Profil yenilənmədi.";
    }
}
?>

<!DOCTYPE html>
<html lang="az">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Yenilə</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .update-container {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1);
            width: 400px;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #555;
        }

        input[type="text"],
        input[type="date"],
        input[type="file"],
        button {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        input[type="radio"] {
            margin-right: 10px;
        }

        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="update-container">
        <h1>Profil Yenilə</h1>
        <form method="POST" enctype="multipart/form-data">
            <label for="first_name">Ad:</label>
            <input type="text" id="first_name" name="first_name" value="<?php echo htmlspecialchars($user['first_name']); ?>" required>

            <label for="last_name">Soyad:</label>
            <input type="text" id="last_name" name="last_name" value="<?php echo htmlspecialchars($user['last_name']); ?>" required>

            <label for="middle_name">Ata adı:</label>
            <input type="text" id="middle_name" name="middle_name" value="<?php echo htmlspecialchars($user['middle_name']); ?>">

            <label for="birth_date">Doğum tarixi:</label>
            <input type="date" id="birth_date" name="birth_date" value="<?php echo htmlspecialchars($user['birth_date']); ?>" required>

            <label for="gender">Cins:</label>
            <input type="radio" name="gender" value="Kişi" <?php echo ($user['gender'] == 'Kişi') ? 'checked' : ''; ?> required> Kişi
            <input type="radio" name="gender" value="Qadın" <?php echo ($user['gender'] == 'Qadın') ? 'checked' : ''; ?> required> Qadın

            <label for="profile_image">Profil şəkili:</label>
            <input type="file" id="profile_image" name="profile_image">

            <button type="submit">Profil Yenilə</button>
        </form>
    </div>
</body>
</html>




























