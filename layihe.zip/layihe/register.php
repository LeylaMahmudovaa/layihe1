<?php
session_start();


session_regenerate_id(true);

$message = "";  

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $middle_name = $_POST['middle_name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $birth_date = $_POST['birth_date'];
    $gender = $_POST['gender'];
    $profile_image = $_FILES['profile_image'];

    
    if ($password !== $confirm_password) {
        $message = "Şifrələr uyğun deyil. Zəhmət olmasa, yenidən cəhd edin.";
    } else {
      
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);

        
        $uploaded_image_path = '';
        if (!empty($profile_image['name'])) {
            $target_dir = "uploads/";
            $image_ext = strtolower(pathinfo($profile_image['name'], PATHINFO_EXTENSION));
            $allowed_extensions = array("jpeg", "jpg", "png");

            if (in_array($image_ext, $allowed_extensions)) {
                $new_image_name = uniqid() . '.' . $image_ext;
                $target_file = $target_dir . $new_image_name;

              
                if (move_uploaded_file($profile_image["tmp_name"], $target_file)) {
                    $uploaded_image_path = $target_file;
                } else {
                    $message = "Fayl yüklənərkən xəta baş verdi.";
                }
            } else {
                $message = "Yalnız JPEG və ya PNG formatında şəkil yükləyə bilərsiniz.";
            }
        }

        if (empty($message)) {
            try {
                
                $conn = new PDO("mysql:host=localhost;dbname=blog_management", "root", "");
                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                
                $stmt = $conn->prepare("SELECT COUNT(*) FROM users WHERE email = :email");
                $stmt->bindParam(':email', $email);
                $stmt->execute();
                $emailCount = $stmt->fetchColumn();

                if ($emailCount > 0) {
                    $message = "Bu e-poçt artıq qeydiyyatdan keçib. Zəhmət olmasa başqa bir e-poçt daxil edin.";
                } else {
                    
                    $stmt = $conn->prepare("INSERT INTO users (first_name, last_name, middle_name, birth_date, gender, email, password, profile_image, role) VALUES (:first_name, :last_name, :middle_name, :birth_date, :gender, :email, :password, :profile_image, 'user')");
                    $stmt->bindParam(':first_name', $first_name);
                    $stmt->bindParam(':last_name', $last_name);
                    $stmt->bindParam(':middle_name', $middle_name);
                    $stmt->bindParam(':birth_date', $birth_date);
                    $stmt->bindParam(':gender', $gender);
                    $stmt->bindParam(':email', $email);
                    $stmt->bindParam(':password', $hashed_password);
                    $stmt->bindParam(':profile_image', $uploaded_image_path);

                    $stmt->execute();

                   
                    header('Location: login.php');
                    exit;
                }
            } catch (PDOException $e) {
                $message = "Xəta baş verdi: " . htmlspecialchars($e->getMessage());
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Qeydiyyat</title>
    <style>
        
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

       
        .register-container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            width: 300px;
        }

      
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

       
        .form-group {
            margin-bottom: 15px;
        }

      
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }

       
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        
        .form-group input[type="submit"] {
            background-color: #5cb85c;
            color: #fff;
            cursor: pointer;
            border: none;
            margin-top: 10px;
            font-weight: bold;
            padding: 10px;
        }

        
        .form-group input[type="submit"]:hover {
            background-color: #4cae4c;
        }

        
        .message {
            text-align: center;
            margin-bottom: 15px;
            color: red;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="register-container">
        <h2>Qeydiyyat</h2>
        
        
        <?php if ($message): ?>
            <div class="message"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <form action="register.php" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="first_name">Ad:</label>
                <input type="text" id="first_name" name="first_name" required>
            </div>
            <div class="form-group">
                <label for="last_name">Soyad:</label>
                <input type="text" id="last_name" name="last_name" required>
            </div>
            <div class="form-group">
                <label for="middle_name">Ata adı:</label>
                <input type="text" id="middle_name" name="middle_name">
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Şifrə:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <label for="confirm_password">Şifrəni təsdiq edin:</label>
                <input type="password" id="confirm_password" name="confirm_password" required>
            </div>
            <div class="form-group">
                <label for="birth_date">Doğum tarixi:</label>
                <input type="date" id="birth_date" name="birth_date" required>
            </div>
            <div class="form-group">
                <label for="gender">Cinsiyyət:</label>
                <select id="gender" name="gender" required>
                    <option value="Male">Kişi</option>
                    <option value="Female">Qadın</option>
                </select>
            </div>
            <div class="form-group">
                <label for="profile_image">Profil şəkli:</label>
                <input type="file" id="profile_image" name="profile_image">
            </div>
            <div class="form-group">
                <input type="submit" value="Qeydiyyat">
            </div>
        </form>
    </div>
</body>
</html>




