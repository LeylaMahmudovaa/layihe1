<?php
session_start();


if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

require 'connection.php';

if (isset($_GET['id'])) {
    $blog_id = intval($_GET['id']);

  
    $stmt = $conn->prepare("SELECT is_published FROM blogs WHERE id = :id");
    $stmt->bindParam(':id', $blog_id, PDO::PARAM_INT);
    $stmt->execute();
    $is_published = $stmt->fetchColumn();
    $stmt->closeCursor();

    
    $new_status = $is_published ? 0 : 1;
    $stmt = $conn->prepare("UPDATE blogs SET is_published = :new_status WHERE id = :id");
    $stmt->bindParam(':new_status', $new_status, PDO::PARAM_INT);
    $stmt->bindParam(':id', $blog_id, PDO::PARAM_INT);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        echo "Blogun yayımlanma statusu dəyişdirildi.";
    } else {
        echo "Xəta baş verdi.";
    }

    $stmt->closeCursor();

   
    header("Location: manage_blogs.php");
    exit();
}
?>
