<?php
require 'connection.php';

session_start();


if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin' || !isset($_SESSION['verified'])) {
    header('Location: login.php');
    exit;
}


if (isset($_GET['id'])) {
    $category_id = $_GET['id'];

    
    if (!filter_var($category_id, FILTER_VALIDATE_INT)) {
        echo "Yanlış kateqoriya ID.";
        exit;
    }

   
    try {
        $stmt = $conn->prepare("DELETE FROM categories WHERE id = :id");
        $stmt->bindParam(':id', $category_id, PDO::PARAM_INT);
        if ($stmt->execute()) {
            header('Location: categories.php');
            exit;
        } else {
            echo "Kateqoriyanı silmək mümkün olmadı.";
        }
    } catch (PDOException $e) {
        error_log("Kateqoriyanı silərkən xəta baş verdi: " . $e->getMessage());
        echo "Xəta: Kateqoriyanı silmək mümkün olmadı.";
    }
} else {
    echo "Yanlış kateqoriya ID.";
    exit;
}
?>




