<?php

session_start();


require 'connection.php';


$blog_id = isset($_GET['id']) ? intval($_GET['id']) : 12;

if ($blog_id <= 0) {
    echo "Yanlış blog ID.";
    exit;
}


$stmt = $conn->prepare("
    SELECT blogs.title, blogs.content, blogs.description, blogs.view_count, categories.name AS category_name, users.first_name, users.last_name
    FROM blogs
    JOIN categories ON blogs.category_id = categories.id
    JOIN users ON blogs.user_id = users.id
    WHERE blogs.id = :id
");
$stmt->bindParam(':id', $blog_id);
$stmt->execute();
$blog = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$blog) {
    echo "Blog tapılmadı.";
    exit;
}


$update_stmt = $conn->prepare("UPDATE blogs SET view_count = view_count + 1 WHERE id = :id");
$update_stmt->bindParam(':id', $blog_id);
$update_stmt->execute();

?>

<!DOCTYPE html>
<html lang="az">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($blog['title']); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .blog-container {
            max-width: 800px;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .blog-title {
            font-size: 28px;
            margin-bottom: 20px;
            color: #333;
        }

        .blog-content {
            font-size: 18px;
            line-height: 1.6;
            color: #555;
        }

        .blog-details {
            margin-top: 20px;
            font-size: 14px;
            color: #888;
        }
    </style>
</head>
<body>
    <div class="blog-container">
        <h1 class="blog-title"><?php echo htmlspecialchars($blog['title']); ?></h1>
        <?php if ($blog['image']): ?>
            <img src="uploads/<?php echo htmlspecialchars($blog['image']); ?>" alt="Blog image" class="blog-image">
        <?php endif; ?>
        <div class="blog-content">
            <?php echo nl2br(htmlspecialchars($blog['content'])); ?>
        </div>
        <div class="blog-details">
            <p><strong>Kateqoriya:</strong> <?php echo htmlspecialchars($blog['category_name']); ?></p>
            <p><strong>Müəllif:</strong> <?php echo htmlspecialchars($blog['first_name'] . ' ' . $blog['last_name']); ?></p>
            <p><strong>Baxış sayı:</strong> <?php echo htmlspecialchars($blog['view_count']); ?></p>
        </div>
    </div>
</body>
</html>
