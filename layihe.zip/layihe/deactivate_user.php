<?php
session_start();


if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

require 'connection.php';

if (isset($_GET['id'])) {
    $user_id = intval($_GET['id']);

    
    $stmt = $conn->prepare("UPDATE users SET role = 'deactivated' WHERE id = :id");
    $stmt->bindValue(':id', $user_id, PDO::PARAM_INT);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        echo "İstifadəçi deaktiv edildi.";
    } else {
        echo "Xəta baş verdi.";
    }

    
    header("Location: manage_users.php");
    exit();
}
?>

