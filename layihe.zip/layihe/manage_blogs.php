<?php
session_start();


if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

require 'connection.php';


$stmt = $conn->query("SELECT blogs.id, blogs.title, blogs.is_published, users.first_name, users.last_name 
                      FROM blogs 
                      JOIN users ON blogs.user_id = users.id");

echo "<h1>Bloglar</h1>";
echo "<table border='1'>
        <tr>
            <th>ID</th>
            <th>Başlıq</th>
            <th>Yayım Statusu</th>
            <th>Yaradıcı</th>
            <th>Əməliyyat</th>
        </tr>";

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo "<tr>
            <td>{$row['id']}</td>
            <td><a href='blog_detail.php?id={$row['id']}'>{$row['title']}</a></td>
            <td>" . ($row['is_published'] ? 'Yayımlandı' : 'Yayımlanmadı') . "</td>
            <td>{$row['first_name']} {$row['last_name']}</td>
            <td>
                <a href='publish_blog.php?id={$row['id']}'>" . ($row['is_published'] ? 'Yayımdan Çıxar' : 'Yayımla') . "</a> |
                <a href='delete_blog.php?id={$row['id']}'>Sil</a>
            </td>
          </tr>";
}

echo "</table>";
?>

