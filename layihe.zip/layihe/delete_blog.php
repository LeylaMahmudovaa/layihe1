<?php
session_start();


if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

require 'connection.php';

if (isset($_GET['id'])) {
    $blog_id = intval($_GET['id']);

    
    $stmt = $conn->prepare("DELETE FROM blogs WHERE id = :id");
    $stmt->bindValue(':id', $blog_id, PDO::PARAM_INT);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        echo "Blog silindi.";
    } else {
        echo "Xəta baş verdi.";
    }

    
    header("Location: manage_blogs.php");
    exit();
}
?>
