<?php
try {
   
    $conn = new PDO("mysql:host=localhost;dbname=blog_management", "root", "");
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


    $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

    echo "Verilənlər bazasına uğurla qoşuldu.";

} catch (PDOException $e) {
   
    echo "Verilənlər bazasına qoşulma uğursuz oldu: " . $e->getMessage(); 
    exit;
}
?>


