-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 25, 2024 at 10:01 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blog_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

CREATE TABLE `blogs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `content` text DEFAULT NULL,
  `view_count` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `image` varchar(255) DEFAULT NULL,
  `is_published` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` (`id`, `user_id`, `category_id`, `title`, `description`, `content`, `view_count`, `created_at`, `updated_at`, `image`, `is_published`) VALUES
(2, NULL, 4, 'jj', 'oioiio', 'jkkjjooo', 0, '2024-08-25 06:15:02', '2024-08-25 06:15:02', '66cacbe6ea63c_kaka_clipdrop-relight 1 (1).jpg', 0),
(7, NULL, 3, 'isaioio', 'iosao', 'ksasa', 0, '2024-08-25 14:16:12', '2024-08-25 14:16:12', '66cb3cacb7a0d_kaka_clipdrop-relight 1 (1).jpg', 0),
(8, NULL, 2, 'oo', 'koo', 'kkjk', 0, '2024-08-25 16:41:00', '2024-08-25 16:41:00', '66cb5e9cc63ae_dhfhr.PNG', 0),
(15, 19, 4, 'uwiiedwi', 'podsopo', 'kdskllkdkals', 0, '2024-08-25 19:52:02', '2024-08-25 19:52:02', '66cb8b62cd96e_DALL·E 2024-08-23 03.00.01 - An anime-style depiction of a man with roses on his head. The man has medium-length hair and a calm, serene expression. The roses are lush and vibrant.webp', 0),
(16, 19, 2, 'sdlkaslkodx', 'jkjsjzk', 'kjesiaoiw', 0, '2024-08-25 19:52:28', '2024-08-25 19:52:28', '66cb8b7c41b7b_DALL·E 2024-08-06 21.58.35 - A photo of a young woman with long dark hair, wearing a blue shirt and standing outdoors in a garden with trees and a small house in the background. A.webp', 0),
(17, 19, 2, 'jiuasiawoi', 'pospasp', 'posapoasoap', 0, '2024-08-25 19:52:51', '2024-08-25 19:52:51', '66cb8b9389843_DALL·E 2024-08-06 22.03.19 - A photo of a young woman with long brown hair, wearing a blue shirt and standing outdoors in a garden with trees and a small house in the background. .webp', 0);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`, `created_at`) VALUES
(2, 'fdse', 'ds', '2024-08-15 17:25:28'),
(3, 'fd', 'etwter', '2024-08-16 17:40:50'),
(4, 'fd', 'etwter', '2024-08-16 17:42:45'),
(5, 'dsdsf', 'edsfer', '2024-08-20 16:24:15'),
(6, 'dsdsf', 'edsfer', '2024-08-20 16:27:37'),
(8, 'jjdj', 'jdsj', '2024-08-20 16:32:20'),
(9, 'ysu', 'osoxzpozs', '2024-08-25 15:01:54'),
(10, 'iosoi', 'dxpd', '2024-08-25 15:52:05');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `gender` enum('Male','Female') DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `role` enum('user','admin') DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `middle_name`, `birth_date`, `gender`, `email`, `password`, `profile_image`, `role`, `created_at`) VALUES
(13, 'leyla', 'mahmudova', 'Raqib', '2001-06-05', '', 'leylamahmudova@coders.edu.az', '$2y$10$9QSZYHvhpxqeddQlmxEICeNlRe7/g2BwYkLQBQNyglBdCHj1996E2', '66ca3493dd1bf_kaka_clipdrop-relight 1.jpg', 'user', '2024-08-21 19:40:56'),
(15, 'leyla', 'Mahmudova', 'raqib', '2001-06-12', 'Female', 'admin@example.com', '$2y$10$N1sLhP0EQsuGbqS12d6tZuJ0/8O0Y0t5ReNP7GhVHLyAza/2YI33O', 'uploads/66c7685284fe8.png', 'user', '2024-08-22 16:33:22'),
(17, 'Admin', 'User', '', '1990-01-01', 'Male', 'newadmin@example.com', '$2y$10$vCbLIeFp8o./R7fgipgGZOD3lbK.Kby8pWuhjDdfvRphCghjRC8LW', 'uploads/2b-wBOoaTr6XjXCufcd-pg.jpg', 'admin', '2024-08-25 06:38:49'),
(19, 'leyla', 'Mahmudova', 'raqib', '2003-03-11', 'Female', 'shamakhyvolunteers@gmail.com', '$2y$10$W1Hgc40Wl8fb/zVNySMoB.zYg2V5MVigSLeKIt2q0e2jMmnArfnP6', 'uploads/66cb8abc34c81.png', 'user', '2024-08-25 19:49:16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blogs`
--
ALTER TABLE `blogs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blogs`
--
ALTER TABLE `blogs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `blogs`
--
ALTER TABLE `blogs`
  ADD CONSTRAINT `blogs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `blogs_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
