<?php
session_start();


if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

require 'connection.php';


$stmt = $conn->prepare("SELECT COUNT(*) FROM blogs WHERE DATE(created_at) = CURDATE()");
$stmt->execute();
$blogs_today = $stmt->fetchColumn();


$stmt = $conn->prepare("SELECT COUNT(*) FROM blogs WHERE MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())");
$stmt->execute();
$blogs_this_month = $stmt->fetchColumn();

$stmt->closeCursor();

echo "<h1>Admin Hesabatları</h1>";
echo "<p>Cari gün yaradılan blogların sayı: {$blogs_today}</p>";
echo "<p>Cari ay yaradılan blogların sayı: {$blogs_this_month}</p>";
?>
