<?php
require 'connection.php';

if (isset($_GET['id'])) {
    $blog_id = $_GET['id'];

    
    $stmt = $conn->prepare("SELECT blogs.title, blogs.content, blogs.view_count, blogs.created_at, categories.name AS category_name, users.first_name, users.last_name 
                            FROM blogs 
                            JOIN categories ON blogs.category_id = categories.id
                            JOIN users ON blogs.user_id = users.id
                            WHERE blogs.id = ?");
    $stmt->execute([$blog_id]);

    $blog = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($blog) {
      
        $conn->prepare("UPDATE blogs SET view_count = view_count + 1 WHERE id = ?")->execute([$blog_id]);

        echo "<h1>{$blog['title']}</h1>";
        echo "<p>{$blog['content']}</p>";
        echo "<p>Kateqoriya: {$blog['category_name']}</p>";
        echo "<p>Yaradıcı: {$blog['first_name']} {$blog['last_name']}</p>";
        echo "<p>Baxış sayı: {$blog['view_count']}</p>";
        echo "<p>Yaradılma tarixi: {$blog['created_at']}</p>";
    } else {
        echo "<p>Blog tapılmadı.</p>";
    }
} else {
    echo "<p>Blog ID-si qeyd edilməyib.</p>";
}
?>
