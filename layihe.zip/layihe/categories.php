<?php
require 'connection.php';

session_start();


if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin' || !isset($_SESSION['verified'])) {
    header('Location: login.php');
    exit;
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    $description = isset($_POST['description']) ? trim($_POST['description']) : '';

    if (!empty($name) && !empty($description)) {
        try {
            $stmt = $conn->prepare("INSERT INTO categories (name, description) VALUES (:name, :description)");
            $stmt->bindParam(':name', $name);
            $stmt->bindParam(':description', $description);
            $stmt->execute();
            echo "Kateqoriya uğurla əlavə edildi!";
        } catch (PDOException $e) {
            error_log("Kateqoriya əlavə edilərkən xəta baş verdi: " . $e->getMessage());
            echo "Kateqoriya əlavə edilərkən xəta baş verdi.";
        }
    } else {
        echo "Kateqoriya adı və təsviri boş ola bilməz.";
    }
}


try {
    $stmt = $conn->prepare("SELECT * FROM categories ORDER BY created_at DESC");
    $stmt->execute();
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Kateqoriyaları əldə edərkən xəta baş verdi: " . $e->getMessage());
    echo "Kateqoriyaları əldə edərkən xəta baş verdi.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kateqoriya İdarəetmə</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }

        .create-container, .categories-list {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }

        .form-group input, .form-group textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .form-group input[type="submit"], .action-buttons a {
            background-color: #5cb85c;
            color: #fff;
            cursor: pointer;
            border: none;
            padding: 10px;
            border-radius: 5px;
            text-decoration: none;
            text-align: center;
            display: inline-block;
            margin-right: 10px;
        }

        .form-group input[type="submit"]:hover, .action-buttons a:hover {
            background-color: #4cae4c;
        }

        .categories-list h3 {
            text-align: center;
            color: #333;
        }

        .categories-list ul {
            list-style-type: none;
            padding: 0;
        }

        .categories-list ul li {
            background-color: #f4f4f4;
            padding: 10px;
            border: 1px solid #ddd;
            margin-bottom: 5px;
            border-radius: 5px;
        }

        .action-buttons {
            display: flex;
            justify-content: flex-end;
        }

        .action-buttons a.delete {
            background-color: #d9534f;
        }

        .action-buttons a.delete:hover {
            background-color: #c9302c;
        }
    </style>
</head>
<body>
    <div class="create-container">
        <h2>Yeni Kateqoriya Yarat</h2>
        <form action="categories.php" method="post">
            <div class="form-group">
                <label for="name">Kateqoriya adı:</label>
                <input type="text" id="name" name="name" required>
            </div>
            <div class="form-group">
                <label for="description">Təsvir:</label>
                <textarea id="description" name="description" rows="4" required></textarea>
            </div>
            <div class="form-group">
                <input type="submit" value="Yarat">
            </div>
        </form>
    </div>

    <div class="categories-list">
        <h3>Mövcud Kateqoriyalar</h3>
        <ul>
            <?php if (!empty($categories)): ?>
                <?php foreach ($categories as $category): ?>
                    <li>
                        <strong><?php echo htmlspecialchars($category['name']); ?></strong><br>
                        <?php echo htmlspecialchars($category['description']); ?>
                        <div class="action-buttons">
                            <a href="edit_category.php?id=<?php echo $category['id']; ?>">Redaktə</a>
                            <a href="delete_category.php?id=<?php echo $category['id']; ?>" class="delete" onclick="return confirm('Bu kateqoriyanı silmək istədiyinizdən əminsiniz?');">Sil</a>
                        </div>
                    </li>
                <?php endforeach; ?>
            <?php else: ?>
                <li>Heç bir kateqoriya tapılmadı.</li>
            <?php endif; ?>
        </ul>
    </div>
</body>
</html>




