<?php
session_start(); 


if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

require 'connection.php';


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $title = $_POST['title'];
    $description = $_POST['description'];
    $content = $_POST['content'];
    $category_id = intval($_POST['category_id']);
    $user_id = $_SESSION['user_id']; 

    
    $image = '';
    if (!empty($_FILES['image']['name'])) {
        $target_dir = "uploads/";
        $image = uniqid() . '_' . basename($_FILES['image']['name']);
        $target_file = $target_dir . $image;

        if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
            
        } else {
            echo "Şəkil yüklənmədi.";
            $image = '';
        }
    }

    
    $stmt = $conn->prepare("INSERT INTO blogs (user_id, category_id, title, description, content, image, created_at, updated_at) VALUES (:user_id, :category_id, :title, :description, :content, :image, NOW(), NOW())");
    $stmt->bindParam(':user_id', $user_id);
    $stmt->bindParam(':category_id', $category_id);
    $stmt->bindParam(':title', $title);
    $stmt->bindParam(':description', $description);
    $stmt->bindParam(':content', $content);
    $stmt->bindParam(':image', $image);

    if ($stmt->execute()) {
        echo "Yeni blog uğurla əlavə edildi.";
    } else {
        echo "Blog əlavə edilərkən xəta baş verdi.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yeni Blog Yarat</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .container h1 {
            font-size: 24px;
            margin-bottom: 20px;
        }

        .container label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
        }

        .container input[type="text"],
        .container textarea,
        .container select {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .container button {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        .container button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Yeni Blog Yarat</h1>
        <form action="create_blog.php" method="POST" enctype="multipart/form-data">
            <label for="title">Başlıq:</label>
            <input type="text" id="title" name="title" required>

            <label for="description">Qısa Təsvir:</label>
            <input type="text" id="description" name="description" required>

            <label for="content">Məzmun:</label>
            <textarea id="content" name="content" rows="10" required></textarea>

            <label for="category_id">Kateqoriya:</label>
            <select id="category_id" name="category_id" required>
                <!-- Kateqoriyaları verilənlər bazasından çəkirik -->
                <?php
                $category_stmt = $conn->prepare("SELECT id, name FROM categories");
                $category_stmt->execute();
                $categories = $category_stmt->fetchAll(PDO::FETCH_ASSOC);
                
                foreach ($categories as $category) {
                    echo '<option value="' . $category['id'] . '">' . htmlspecialchars($category['name']) . '</option>';
                }
                ?>
            </select>

            <label for="image">Şəkil:</label>
            <input type="file" id="image" name="image">

            <button type="submit">Blogu Yarat</button>
        </form>
    </div>
</body>
</html>





