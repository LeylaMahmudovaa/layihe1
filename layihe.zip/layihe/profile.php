<?php
session_start();


if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}


require 'connection.php';


$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM users WHERE id = :id");
$stmt->bindParam(':id', $user_id, PDO::PARAM_INT);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user) {
    $name = isset($user['first_name']) ? htmlspecialchars($user['first_name']) . ' ' . htmlspecialchars($user['last_name']) : 'Ad mövcud deyil';
    $email = isset($user['email']) ? htmlspecialchars($user['email']) : 'Email mövcud deyil';
    $dob = isset($user['birth_date']) ? htmlspecialchars($user['birth_date']) : 'Doğum tarixi mövcud deyil';
    $gender = isset($user['gender']) ? htmlspecialchars($user['gender']) : 'Cins mövcud deyil';
} else {
    $name = 'Ad mövcud deyil';
    $email = 'Email mövcud deyil';
    $dob = 'Doğum tarixi mövcud deyil';
    $gender = 'Cins mövcud deyil';
}
?>

<!DOCTYPE html>
<html lang="az">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .navbar {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
        }

        .navbar ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
        }

        .navbar ul li {
            margin: 0 15px;
        }

        .navbar ul li a {
            color: #fff;
            text-decoration: none;
            font-weight: bold;
        }

        .navbar ul li a:hover {
            text-decoration: underline;
        }

        .profile {
            padding: 20px;
            background-color: #fff;
            margin: 20px auto;
            width: 300px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .profile h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .profile p {
            margin: 10px 0;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <ul>
            <li><a href="user_dashboard.php">Dashboard</a></li>
            <li><a href="profile.php">Profil</a></li>
            <li><a href="create_blog.php">Yeni Blog Yarat</a></li>
            <li><a href="logout.php">Çıxış</a></li>
        </ul>
    </div>

    <div class="profile">
        <h2>Profil Məlumatları</h2>
        <p><strong>Ad:</strong> <?php echo $name; ?></p>
        <p><strong>Email:</strong> <?php echo $email; ?></p>
        <p><strong>Doğum tarixi:</strong> <?php echo $dob; ?></p>
        <p><strong>Cins:</strong> <?php echo $gender; ?></p>
    </div>
</body>
</html>
