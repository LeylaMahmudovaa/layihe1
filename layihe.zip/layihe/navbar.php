<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Navigation Bar</title>
    <style>
        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #333;
        }

        nav ul li {
            float: left;
            display: inline;
        }

        nav ul li a {
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        nav ul li a:hover {
            background-color: #111;
        }

        nav ul li:last-child {
            float: right;
            display: flex;
            align-items: center;
            color: white;
            padding-right: 16px;
        }
    </style>
</head>
<body>

<nav>
    <ul>
        <li><a href="register.php">Register</a></li>
        <li><a href="login.php">Login</a></li>

        <?php
        if (isset($_SESSION['user_id'])) {
            try {
               
                $conn = new PDO("mysql:host=localhost;dbname=blog_management", "root", "");
                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                $stmt = $conn->prepare('SELECT first_name FROM users WHERE id = :id');
                $stmt->bindParam(':id', $_SESSION['user_id']);
                $stmt->execute();
                $user = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($user) {
                   
                    echo '<li>';
                    echo htmlspecialchars($user['first_name']);
                    echo '</li>';
                    echo '<li><a href="logout.php">Logout</a></li>';
                }

            } catch (PDOException $e) {
              
                echo '<li style="color: red;">Xəta baş verdi.</li>';
                error_log("Connection failed: " . $e->getMessage());
            }
        }
        ?>
    </ul>
</nav>

</body>
</html>


















