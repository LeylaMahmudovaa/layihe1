<?php
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin' || !isset($_SESSION['verified'])) {
    header("Location: login.php");
    exit();
}


$conn = new PDO("mysql:host=localhost;dbname=blog_management", "root", "");
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$stmt = $conn->prepare("SELECT first_name, last_name, profile_image FROM users WHERE id = :id");
$stmt->bindParam(':id', $_SESSION['user_id'], PDO::PARAM_INT);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user) {
    $profile_image = !empty($user['profile_image']) ? htmlspecialchars($user['profile_image']) : 'default_profile.png';
    $full_name = htmlspecialchars($user['first_name']) . ' ' . htmlspecialchars($user['last_name']);
}
?>

<!DOCTYPE html>
<html lang="az">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .navbar {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .navbar ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
        }

        .navbar ul li {
            margin: 0 15px;
        }

        .navbar ul li a {
            color: #fff;
            text-decoration: none;
            font-weight: bold;
        }

        .navbar ul li a:hover {
            text-decoration: underline;
        }

        .profile {
            display: flex;
            align-items: center;
        }

        .profile img {
            border-radius: 50%;
            width: 40px;
            height: 40px;
            margin-right: 10px;
            object-fit: cover;
        }

        .profile span {
            color: #fff;
            font-weight: bold;
        }

        .dashboard {
            padding: 20px;
        }

        .stats, .actions {
            background-color: #fff;
            padding: 15px;
            margin-top: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .actions button {
            padding: 10px 20px;
            margin-right: 10px;
            background-color: #5cb85c;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .actions button:hover {
            background-color: #4cae4c;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <ul>
            <li><a href="manage_users.php">İstifadəçilər</a></li>
            <li><a href="manage_blogs.php">Bloglar</a></li>
            <li><a href="categories.php">Kateqoriyalar</a></li>
            <li><a href="admin_report.php">Hesabatlar</a></li>
            <li><a href="logout.php">Çıxış</a></li>
        </ul>
        <?php if (isset($user)): ?>
        <div class="profile">
            <img src="<?php echo $profile_image; ?>" alt="Profile Image">
            <span><?php echo $full_name; ?></span>
        </div>
        <?php endif; ?>
    </div>

    <div class="dashboard">
        <h3>Xoş gəlmisiniz, Admin!</h3>
        <div class="stats">
            <p>Bu gün əlavə edilmiş bloglar: 10</p>
            <p>Cari ayda aktiv istifadəçilər: 45</p>
        </div>
        <div class="actions">
            <button onclick="location.href='create_category.php'">Yeni Kateqoriya Yarat</button>
            <button onclick="location.href='search.php'">Axtarış Səhifəsinə Get</button>
        </div>
    </div>
</body>
</html>












