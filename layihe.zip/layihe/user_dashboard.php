<?php
session_start();


if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

require 'connection.php';


$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM users WHERE id = :id");
$stmt->bindParam(':id', $user_id, PDO::PARAM_INT);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user) {
    $name = htmlspecialchars($user['first_name']) . ' ' . htmlspecialchars($user['last_name']);
    $email = htmlspecialchars($user['email']);
    $dob = htmlspecialchars($user['birth_date']);
    $gender = htmlspecialchars($user['gender']);
    $profile_image = !empty($user['profile_image']) ? htmlspecialchars($user['profile_image']) : 'uploads/default_profile.png';
} else {
    echo "İstifadəçi məlumatları tapılmadı.";
    exit();
}


$blogs_stmt = $conn->prepare("SELECT * FROM blogs WHERE user_id = :user_id ORDER BY created_at DESC");
$blogs_stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
$blogs_stmt->execute();
$blogs = $blogs_stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="az">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .navbar {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
        }

        .navbar ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .navbar ul li {
            margin: 0 15px;
            display: flex;
            align-items: center;
        }

        .navbar ul li a {
            color: #fff;
            text-decoration: none;
            font-weight: bold;
        }

        .navbar ul li a:hover {
            text-decoration: underline;
        }

        .navbar ul li img {
            width: 40px;
            height: 40px;
            object-fit: cover;
            border-radius: 50%;
            margin-right: 10px;
        }

        .dashboard {
            padding: 20px;
        }

        .profile {
            background-color: #fff;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .profile img {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 50%;
            margin-bottom: 15px;
        }

        .profile h2 {
            margin-top: 0;
        }

        .profile p {
            margin: 5px 0;
        }

        .update-btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 10px;
        }

        .update-btn:hover {
            background-color: #45a049;
        }

        .blogs {
            background-color: #fff;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .blogs h3 {
            margin-top: 0;
        }

        .blog-item {
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }

        .blog-item:last-child {
            border-bottom: none;
        }

        .blog-item img {
            width: 30%;
            height: 300px;
            object-fit: cover;
            border-radius: 5px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <ul>
            <li><a href="user_dashboard.php">Dashboard</a></li>
            <li><a href="create_blog.php">Yeni Blog Yarat</a></li>
            <li><a href="logout.php">Çıxış</a></li>
            <li><a href="profile.php"><img src="<?php echo $profile_image; ?>" alt="Profil Şəkli">Profil</a></li>
        </ul>
    </div>

    <div class="dashboard">
        <div class="profile">
            <img src="<?php echo $profile_image; ?>" alt="Profil Şəkli">
            <h2>Xoş gəlmisiniz, <?php echo $name; ?>!</h2>
            <p><strong>Email:</strong> <?php echo $email; ?></p>
            <p><strong>Doğum tarixi:</strong> <?php echo $dob; ?></p>
            <p><strong>Cins:</strong> <?php echo $gender; ?></p>
            <a href="update.php" class="update-btn">Profil Yenilə</a>
        </div>

        <div class="blogs">
            <h3>Yaradılmış Bloglar</h3>
            <?php if (!empty($blogs)): ?>
                <?php foreach ($blogs as $blog): ?>
                    <div class="blog-item">
                        <h4><?php echo htmlspecialchars($blog['title']); ?></h4>
                        <p><?php echo htmlspecialchars($blog['description']); ?></p>
                        <?php if (!empty($blog['image'])): ?>
                            <img src="uploads/<?php echo htmlspecialchars($blog['image']); ?>" alt="Blog Image">
                        <?php endif; ?>
                        <p><a href="view_blog.php?id=<?php echo $blog['id']; ?>">Daha ətraflı oxu</a></p>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Heç bir blog yaratmamısınız.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>










