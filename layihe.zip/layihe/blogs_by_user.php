<?php
session_start();


if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

require 'connection.php';


$stmt = $conn->query("SELECT users.first_name, users.last_name, COUNT(blogs.id) as blog_count FROM users LEFT JOIN blogs ON blogs.user_id = users.id GROUP BY users.id");

echo "<h2>İstifadəçilərə Görə Blogların Sayı</h2>";
echo "<table border='1'>
        <tr>
            <th>İstifadəçi</th>
            <th>Blog Sayı</th>
        </tr>";

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $full_name = "{$row['first_name']} {$row['last_name']}";
    echo "<tr>
            <td>{$full_name}</td>
            <td>{$row['blog_count']}</td>
          </tr>";
}

echo "</table>";
?>
