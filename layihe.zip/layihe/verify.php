<?php
session_start();

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $otp = $_POST['otp'];

    
    if (isset($_SESSION['otp']) && $_SESSION['otp'] == $otp) {
      
        $_SESSION['verified'] = true;

       
        unset($_SESSION['otp']);

        
        if ($_SESSION['role'] == 'admin') {
            header('Location: admin_dashboard.php'); 
        } else {
            header('Location: user_dashboard.php'); 
        }
        exit();
    } else {
        
        $error = "Yanlış OTP!";
    }
}
?>
<!DOCTYPE html>
<html lang="az">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OTP Doğrulama</title>
</head>
<body>
    <h2>OTP Doğrulama</h2>
    <form method="POST">
        <div>
            <label for="otp">OTP:</label>
            <input type="text" id="otp" name="otp" required>
        </div>
        <div>
            <button type="submit">Təsdiqlə</button>
        </div>
        <?php if ($error): ?>
            <p style="color: red;"><?php echo $error; ?></p>
        <?php endif; ?>
    </form>
</body>
</html>













