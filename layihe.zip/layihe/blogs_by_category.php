<?php
session_start();


if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

require 'connection.php';


$stmt = $conn->query("SELECT categories.name, COUNT(blogs.id) as blog_count FROM categories LEFT JOIN blogs ON blogs.category_id = categories.id GROUP BY categories.name");

echo "<h2>Hər Kateqoriyada Neçə Blog Olduğu</h2>";
echo "<table border='1'>
        <tr>
            <th>Kateqoriya</th>
            <th>Blog Sayı</th>
        </tr>";

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo "<tr>
            <td>{$row['name']}</td>
            <td>{$row['blog_count']}</td>
          </tr>";
}

echo "</table>";
?>
