<?php
session_start();

if (!isset($_SESSION['user_id']) || !isset($_SESSION['verified'])) {
    header("Location: login.php");
    exit();
}

$conn = new PDO("mysql:host=localhost;dbname=blog_management", "root", "");
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$results = []; 

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $title = !empty($_GET['title']) ? htmlspecialchars($_GET['title']) : '';
    $description = !empty($_GET['description']) ? htmlspecialchars($_GET['description']) : '';
    $user_id = !empty($_GET['user_id']) ? htmlspecialchars($_GET['user_id']) : '';
    $category = !empty($_GET['category']) ? htmlspecialchars($_GET['category']) : '';

    $query = "SELECT * FROM blogs WHERE 1=1";
    
    if ($title) {
        $query .= " AND title LIKE :title";
    }
    if ($description) {
        $query .= " AND description LIKE :description";
    }
    if ($user_id) {
        $query .= " AND user_id = :user_id";
    }
    if ($category) {
        $query .= " AND category_id = :category";
    }

    $stmt = $conn->prepare($query);

    if ($title) {
        $stmt->bindValue(':title', "%$title%", PDO::PARAM_STR);
    }
    if ($description) {
        $stmt->bindValue(':description', "%$description%", PDO::PARAM_STR);
    }
    if ($user_id) {
        $stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
    }
    if ($category) {
        $stmt->bindValue(':category', $category, PDO::PARAM_INT);
    }

    $stmt->execute();
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="az">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Axtarış Nəticələri</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        .results {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 800px;
            margin: 0 auto;
        }

        .result-item {
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #ddd;
        }

        .result-item:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }

        h2 {
            color: #333;
        }

        p {
            color: #666;
        }
    </style>
</head>
<body>
    <div class="results">
        <h1>Axtarış Nəticələri</h1>
        <?php if (!empty($results)): ?>
            <?php foreach ($results as $result): ?>
                <div class="result-item">
                    <h2><?php echo htmlspecialchars($result['title']); ?></h2>
                    <p><?php echo htmlspecialchars($result['description']); ?></p>
                    <p><strong>İstifadəçi ID:</strong> <?php echo htmlspecialchars($result['user_id']); ?></p>
                    <p><strong>Kateqoriya ID:</strong> <?php echo htmlspecialchars($result['category_id']); ?></p>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>Heç bir nəticə tapılmadı.</p>
        <?php endif; ?>
    </div>
</body>
</html>




