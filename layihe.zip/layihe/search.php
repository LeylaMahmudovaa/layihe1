<!DOCTYPE html>
<html lang="az">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Axtarış Səhifəsi</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .search-form {
            background-color: #fff;
            padding: 20px;
            margin-top: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 500px;
            margin-left: auto;
            margin-right: auto;
        }

        .search-form input[type="text"],
        .search-form select {
            width: calc(100% - 16px);
            padding: 8px;
            margin: 8px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .search-form button {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            box-sizing: border-box;
            margin-top: 10px;
            font-size: 16px;
            font-weight: bold;
        }

        .search-form button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="search-form">
        <h3>Axtarış</h3>
        <form method="GET" action="search_results.php">
            <input type="text" name="title" placeholder="Başlıq">
            <input type="text" name="description" placeholder="Təsvir">
            <input type="text" name="creator" placeholder="Müəllif">
            <select name="category">
                <option value="">Kateqoriyanı seçin</option>
                <option value="1">Kateqoriya 1</option>
                <option value="2">Kateqoriya 2</option>
                <option value="3">Kateqoriya 3</option>
            </select>
            <button type="submit">Axtar</button> <!-- Düymə burada yerləşdirilib -->
        </form>
    </div>
</body>
</html>





