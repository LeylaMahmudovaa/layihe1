<?php
session_start();


if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

require 'connection.php';

$stmt = $conn->query("SELECT id, first_name, last_name, email, role, created_at FROM users");


echo "<h1>İstifadəçilər</h1>";
echo "<table border='1'>
        <tr>
            <th>ID</th>
            <th>Ad</th>
            <th>Soyad</th>
            <th>Email</th>
            <th>Rolu</th>
            <th>Qeydiyyat Tarixi</th>
            <th>İşlem</th>
        </tr>";

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {  // fetch_assoc əvəzinə fetch(PDO::FETCH_ASSOC) istifadə olunur
    echo "<tr>
            <td>{$row['id']}</td>
            <td>{$row['first_name']}</td>
            <td>{$row['last_name']}</td>
            <td>{$row['email']}</td>
            <td>{$row['role']}</td>
            <td>{$row['created_at']}</td>
            <td>
                <a href='deactivate_user.php?id={$row['id']}'>Deaktiv et</a>
            </td>
          </tr>";
}

echo "</table>";
?>
