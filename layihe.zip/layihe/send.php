<?php
session_start();


$_SESSION['otp'] = '123456'; 
$_SESSION['email'] = 'admin@example.com'; 


header('Location: verify.php');
exit;
?>




